/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Building2, Laptop, ShieldCheck, Activity, ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';

interface HeroProps {
  onLearnMoreClick: () => void;
  onExploreHMSClick: () => void;
}

export default function Hero({ onLearnMoreClick, onExploreHMSClick }: HeroProps) {
  const [activePillar, setActivePillar] = useState<'physical' | 'digital'>('digital');

  return (
    <section
      id="hero-section"
      className="relative min-h-screen bg-[#05070a] text-white pt-28 pb-20 px-6 md:px-8 flex items-center overflow-hidden"
    >
      {/* Background Subtle Mesh Gradient matching Sophisticated Dark */}
      <div className="absolute top-[-100px] right-[-100px] w-[400px] h-[400px] bg-blue-900/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-150px] left-[-50px] w-[350px] h-[350px] bg-teal-900/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center relative z-10">
        {/* Pitch Column */}
        <div className="lg:col-span-7 space-y-8 text-left animate-in fade-in duration-500">
          {/* Tagline Badge */}
          <div className="inline-block px-3 py-1.5 border border-teal-500/30 bg-teal-500/5 rounded-full text-[10px] text-teal-400 uppercase tracking-[0.2em]">
            <span className="flex items-center gap-1.5">
              <Sparkles className="h-3 w-3" />
              Next-Gen Facility Excellence
            </span>
          </div>

          {/* Heading */}
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-normal text-white leading-[1.1] tracking-tight">
            Harmonizing <span className="italic text-teal-400">Infrastructure</span> with Intelligence.
          </h1>

          {/* Supporting Text */}
          <div className="max-w-xl border-l-2 border-teal-500/50 pl-6">
            <h2 className="text-xs font-bold text-teal-400 mb-1 uppercase tracking-widest">Bridging Physical & Digital</h2>
            <p className="font-sans text-sm md:text-base text-white/70 leading-relaxed">
              We redefine healthcare operations by bridging the gap between physical infrastructure building and Hospital Management System (HMS) software. Our integrated approach optimizes workflows and facility management for seamless coordination.
            </p>
          </div>

          {/* Hero CTAs */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
            <button
              id="hero-cta-hms"
              onClick={onExploreHMSClick}
              className="font-sans inline-flex items-center justify-center space-x-2.5 bg-white hover:bg-teal-400 text-black px-8 py-3.5 rounded-none font-bold text-xs uppercase tracking-widest transition-all cursor-pointer shadow-lg shadow-teal-400/5"
            >
              <span>Explore HMS</span>
              <Activity className="h-4 w-4" />
            </button>
            <button
              id="hero-cta-infrastructure"
              onClick={onLearnMoreClick}
              className="font-sans inline-flex items-center justify-center space-x-2 bg-transparent border border-white/20 hover:border-teal-400 text-white px-8 py-3.5 rounded-none font-bold text-xs uppercase tracking-widest transition-all cursor-pointer"
            >
              <span>Infrastructure</span>
              <Building2 className="h-4 w-4" />
            </button>
          </div>

          {/* Credibility Benchmarks */}
          <div className="grid grid-cols-3 gap-6 pt-6 border-t border-white/10">
            <div>
              <span className="block font-serif text-2xl md:text-3xl font-normal text-white">100%</span>
              <span className="block font-sans text-[10px] uppercase tracking-widest text-white/40 mt-1">Compliance</span>
            </div>
            <div>
              <span className="block font-serif text-2xl md:text-3xl font-normal text-teal-400">40%+</span>
              <span className="block font-sans text-[10px] uppercase tracking-widest text-white/40 mt-1">Workflow Boost</span>
            </div>
            <div>
              <span className="block font-serif text-2xl md:text-3xl font-normal text-white">Turnkey</span>
              <span className="block font-sans text-[10px] uppercase tracking-widest text-white/40 mt-1">End-to-End</span>
            </div>
          </div>
        </div>

        {/* Interactive Feature Showcase Column */}
        <div className="lg:col-span-5 w-full">
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 md:p-8 backdrop-blur-md relative shadow-2xl">
            {/* Top Toggle Switch */}
            <div className="flex bg-[#05070a] p-1.5 rounded-xl border border-white/10 mb-6">
              <button
                id="toggle-pillar-digital"
                onClick={() => setActivePillar('digital')}
                className={`flex-1 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center space-x-2 ${
                  activePillar === 'digital'
                    ? 'bg-teal-400 text-slate-950 shadow-md shadow-teal-500/10'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                <Laptop className="h-4 w-4" />
                <span>HMS Software</span>
              </button>
              <button
                id="toggle-pillar-physical"
                onClick={() => setActivePillar('physical')}
                className={`flex-1 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center space-x-2 ${
                  activePillar === 'physical'
                    ? 'bg-teal-400 text-slate-950 shadow-md shadow-teal-500/10'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                <Building2 className="h-4 w-4" />
                <span>Building</span>
              </button>
            </div>

            {/* Active Pillar Panel */}
            {activePillar === 'digital' ? (
              <div id="hms-pillar-panel" className="space-y-6 animate-in fade-in duration-300">
                <div className="flex items-start justify-between">
                  <h3 className="font-serif text-lg text-white">Digital Facility Orchestration</h3>
                  <span className="bg-teal-500/10 text-teal-400 text-[9px] uppercase font-bold tracking-widest px-2 py-1 rounded border border-teal-500/20">
                    Active Suite
                  </span>
                </div>
                <p className="font-sans text-xs md:text-sm text-white/60 leading-relaxed">
                  Our custom HMS acts as the digital nervous system of your hospital, linking clinical data directly with administrative, operational, and billing workflows.
                </p>

                <div className="space-y-2.5">
                  <div className="flex items-center space-x-3 bg-[#05070a]/60 p-3 rounded-lg border border-white/5">
                    <CheckCircle2 className="h-4 w-4 text-teal-400 flex-shrink-0" />
                    <span className="font-sans text-xs text-white/80">
                      Real-time vacant/occupied bed mapping
                    </span>
                  </div>
                  <div className="flex items-center space-x-3 bg-[#05070a]/60 p-3 rounded-lg border border-white/5">
                    <CheckCircle2 className="h-4 w-4 text-teal-400 flex-shrink-0" />
                    <span className="font-sans text-xs text-white/80">
                      Centralized electronic prescription and lab dispatcher
                    </span>
                  </div>
                  <div className="flex items-center space-x-3 bg-[#05070a]/60 p-3 rounded-lg border border-white/5">
                    <CheckCircle2 className="h-4 w-4 text-teal-400 flex-shrink-0" />
                    <span className="font-sans text-xs text-white/80">
                      Unified billing linking pharmacy and ward occupancy
                    </span>
                  </div>
                </div>

                <div className="bg-teal-950/20 border border-teal-500/10 p-3 rounded-xl flex items-center justify-between text-[11px]">
                  <span className="text-white/60">Try our live ROI calculator below</span>
                  <span className="text-teal-400 font-bold uppercase tracking-widest cursor-pointer hover:underline flex items-center" onClick={onExploreHMSClick}>
                    Calculate <ArrowRight className="h-3 w-3 ml-1" />
                  </span>
                </div>
              </div>
            ) : (
              <div id="infrastructure-pillar-panel" className="space-y-6 animate-in fade-in duration-300">
                <div className="flex items-start justify-between">
                  <h3 className="font-serif text-lg text-white">NABH-Compliant Building</h3>
                  <span className="bg-teal-500/10 text-teal-400 text-[9px] uppercase font-bold tracking-widest px-2 py-1 rounded border border-teal-500/20">
                    Physical
                  </span>
                </div>
                <p className="font-sans text-xs md:text-sm text-white/60 leading-relaxed">
                  We construct healthcare structures from scratch or renovate existing setups to strict infection control, cleanroom isolation, and medical gas pipeline requirements.
                </p>

                <div className="space-y-2.5">
                  <div className="flex items-center space-x-3 bg-[#05070a]/60 p-3 rounded-lg border border-white/5">
                    <CheckCircle2 className="h-4 w-4 text-teal-400 flex-shrink-0" />
                    <span className="font-sans text-xs text-white/80">
                      Modular sterile Operating Theatres with laminar airflow
                    </span>
                  </div>
                  <div className="flex items-center space-x-3 bg-[#05070a]/60 p-3 rounded-lg border border-white/5">
                    <CheckCircle2 className="h-4 w-4 text-teal-400 flex-shrink-0" />
                    <span className="font-sans text-xs text-white/80">
                      Computerized copper pipeline system for clinical gas
                    </span>
                  </div>
                  <div className="flex items-center space-x-3 bg-[#05070a]/60 p-3 rounded-lg border border-white/5">
                    <CheckCircle2 className="h-4 w-4 text-teal-400 flex-shrink-0" />
                    <span className="font-sans text-xs text-white/80">
                      Strict spatial layout zoning to manage pathogen flow
                    </span>
                  </div>
                </div>

                <div className="bg-[#05070a]/80 border border-white/10 p-3 rounded-xl flex items-center justify-between text-[11px]">
                  <span className="text-white/60">Learn about our custom cleanroom standards</span>
                  <span className="text-teal-400 font-bold uppercase tracking-widest cursor-pointer hover:underline flex items-center" onClick={onLearnMoreClick}>
                    Read more <ArrowRight className="h-3 w-3 ml-1" />
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
