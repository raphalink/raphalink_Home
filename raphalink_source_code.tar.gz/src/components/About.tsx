/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ShieldCheck, HeartPulse, Sparkles, Activity, FileCheck, Landmark, MapPin, Building2, Layers, FlameKindling } from 'lucide-react';

export default function About() {
  const values = [
    {
      title: 'Structural Integrity',
      desc: 'We construct hospital layouts that physically optimize physician paths, reduce pathogen transfer risk, and ensure structural stability.',
      icon: <Landmark className="h-5 w-5 text-teal-400" />
    },
    {
      title: 'Operational Logic',
      desc: 'Our Hospital Management System automates workflow assignments, tracks wards, and syncs pharmacy stock-outs instantly.',
      icon: <Activity className="h-5 w-5 text-teal-400" />
    },
    {
      title: 'End-to-End Compliance',
      desc: 'All engineering satisfies rigorous national and global benchmarks including NABH, JCI, NFPA-99, and modular cleanroom standards.',
      icon: <FileCheck className="h-5 w-5 text-teal-400" />
    }
  ];

  const packages = [
    {
      name: 'Rapha MediStack Enterprise',
      tagline: 'Institutional Scale',
      desc: 'The ultimate infrastructure platform tailored for multi-specialty hospitals, clinical research centres, and large-scale medical colleges.',
      icon: <Building2 className="h-6 w-6 text-teal-400" />,
      features: ['Laminar Airflow Cleanrooms', 'Computerized Copper Manifolds', 'Smart HMS Enterprise Integration']
    },
    {
      name: 'Rapha CliniStack',
      tagline: 'Physical Clinic Units',
      desc: 'Engineered specifically for specialized clinic workflows, such as establishing premium dental clinics, dermatology suites, and diagnostics labs.',
      icon: <Layers className="h-6 w-6 text-teal-400" />,
      features: ['Dental / Derma Custom Fitouts', 'Aseptic Infrastructure & Spatial Ergonomics', 'Optimized Spatial Patient Flow']
    },
    {
      name: 'Rapha CareStack',
      tagline: 'Agile Entry Product',
      desc: 'A flexible starter package and entry product built strictly around your custom facility requirements to initiate digital-physical coordination.',
      icon: <FlameKindling className="h-6 w-6 text-teal-400" />,
      features: ['Tailored Spatial Planning', 'Basic HMS Module Setups', 'Rapid Construction Timelines']
    }
  ];

  return (
    <section
      id="about"
      className="bg-[#05070a] text-white py-24 px-6 md:px-8 relative scroll-mt-20 border-t border-white/10"
    >
      <div className="max-w-7xl mx-auto space-y-24">
        {/* About Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <span className="text-teal-400 font-sans text-xs uppercase tracking-[0.2em] font-bold block">
            Who We Are
          </span>
          <h2 className="font-serif text-3xl md:text-4xl font-normal text-white tracking-tight animate-fade-in">
            Bridging Physical Wards with Digital Flow
          </h2>
          <div className="h-0.5 w-12 bg-teal-400 mx-auto rounded" />
          <p className="font-sans text-sm md:text-base text-white/60">
            RaphaLink Healthcare Pvt Ltd is a pioneering healthcare solutions firm. We design, construct, and digitize medical facilities to establish harmonious, coordinated workflows.
          </p>
        </div>

        {/* Dynamic Story Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Detailed Narrative - Col 7 */}
          <div className="lg:col-span-7 space-y-6">
            <h3 className="font-serif text-2xl font-normal text-white leading-snug">
              Our Vision: Solving the Hospital Integration Gap
            </h3>
            <p className="font-sans text-white/70 leading-relaxed text-sm md:text-base">
              Historically, hospital development has been severely fragmented. A medical facility is built by general contractors with limited clinical spatial understanding. Then, a generic off-the-shelf software is forced upon clinical teams, mismatching the physical ward layouts and administrative realities.
            </p>
            <p className="font-sans text-white/70 leading-relaxed text-sm md:text-base">
              At **RaphaLink Healthcare**, we solve this exact gap. We provide **turnkey infrastructure construction**—including specialized laminar airflow cleanrooms, sterile modular OTs, and computerized copper pipelines for clinical gas supply—alongside **custom-coded HMS software**. This hybrid coordination means the digital hospital dashboard aligns perfectly with the actual ward coordinates, guaranteeing seamless, high-speed clinical dispatch.
            </p>

            {/* Regional Trust and Milestone Highlights */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
              <div className="bg-white/5 border border-white/10 p-5 rounded-lg flex items-start space-x-3.5">
                <MapPin className="h-5 w-5 text-teal-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-serif text-sm text-white">Trivandrum Kerala Milestone</h4>
                  <p className="font-sans text-[11px] text-white/50 mt-1 leading-relaxed">
                    Successfully completed a full-scale healthcare infrastructure and spatial integration project in Trivandrum, Kerala, delivering high-speed operational synchronizations.
                  </p>
                </div>
              </div>

              <div className="bg-white/5 border border-white/10 p-5 rounded-lg flex items-start space-x-3.5">
                <ShieldCheck className="h-5 w-5 text-teal-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-serif text-sm text-white">Oral-D Dental Imaging Center</h4>
                  <p className="font-sans text-[11px] text-white/50 mt-1 leading-relaxed">
                    Trusted Partner for Oral-D Dental Imaging Center, helping with end-to-end center setup, advanced medical imaging layouts, and clinical compliance.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Visual Value Cards - Col 5 */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white/5 border border-white/10 rounded-xl p-6 space-y-6">
              <h4 className="font-sans text-[10px] font-bold text-white/40 uppercase tracking-widest block border-b border-white/5 pb-3">
                Our Core Paradigms
              </h4>

              <div className="space-y-6">
                {values.map((v, i) => (
                  <div key={i} className="flex items-start space-x-4">
                    <div className="bg-[#05070a]/50 border border-white/10 p-2 rounded-lg flex-shrink-0 shadow-sm">
                      {v.icon}
                    </div>
                    <div>
                      <h5 className="font-serif text-sm text-white">{v.title}</h5>
                      <p className="font-sans text-xs text-white/50 mt-1 leading-relaxed">{v.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* New Section: Infrastructure Development Packages */}
        <div className="space-y-12 pt-6">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-teal-400 font-sans text-xs uppercase tracking-[0.2em] font-bold block">
              Execution Plans
            </span>
            <h3 className="font-serif text-2xl md:text-3xl font-normal text-white">
              Healthcare Infrastructure Development Packages
            </h3>
            <p className="font-sans text-xs md:text-sm text-white/50">
              Select our modular packages designed to easily scale from individual clinics to expansive multi-specialty healthcare networks.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {packages.map((pkg, i) => (
              <div 
                key={i} 
                className="bg-white/5 border border-white/10 rounded-xl p-6 flex flex-col justify-between space-y-6 hover:border-teal-400/20 transition-all group duration-300"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="bg-[#05070a]/50 border border-white/10 p-3 rounded-lg group-hover:border-teal-400/30 transition-all duration-300">
                      {pkg.icon}
                    </div>
                    <span className="text-[9px] text-teal-400 font-bold uppercase tracking-widest bg-teal-400/10 px-2 py-0.5 rounded border border-teal-500/20">
                      {pkg.tagline}
                    </span>
                  </div>
                  <h4 className="font-serif text-lg text-white group-hover:text-teal-400 transition-colors">
                    {pkg.name}
                  </h4>
                  <p className="font-sans text-xs text-white/60 leading-relaxed">
                    {pkg.desc}
                  </p>
                </div>

                <div className="pt-4 border-t border-white/5 space-y-2">
                  <span className="text-[9px] text-white/40 font-bold uppercase tracking-widest block mb-1">
                    Key Features Included:
                  </span>
                  {pkg.features.map((feat, idx) => (
                    <div key={idx} className="flex items-center space-x-2 text-[11px] text-white/70">
                      <div className="h-1 w-1 bg-teal-400 rounded-full" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Seamless Coordination Banner */}
        <div id="infrastructure" className="bg-white/5 border border-white/10 text-white rounded-xl p-8 md:p-12 relative overflow-hidden shadow-xl scroll-mt-20">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(20,184,166,0.05),transparent_50%)] pointer-events-none" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center relative z-10">
            <div className="space-y-4">
              <span className="text-teal-400 text-xs font-bold uppercase tracking-widest block">
                Physical Engineering Focus
              </span>
              <h3 className="font-serif text-2xl md:text-3xl font-normal text-white">
                Engineered for High-Risk Clinical Success
              </h3>
              <p className="font-sans text-white/60 text-sm leading-relaxed">
                Our building solutions are not merely aesthetic. We design spatial systems that prevent cross-contamination, manage life-support manifold redundancies, and ensure continuous sterile airflow in highly pressurized medical environments.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[#05070a]/60 p-4 rounded-lg border border-white/10">
                <span className="block text-xl font-serif text-teal-400">HTM 02-01</span>
                <span className="block text-[10px] text-white/40 mt-1 uppercase font-semibold">MGPS Standard Copper Piping</span>
              </div>
              <div className="bg-[#05070a]/60 p-4 rounded-lg border border-white/10">
                <span className="block text-xl font-serif text-white">Class 100</span>
                <span className="block text-[10px] text-white/40 mt-1 uppercase font-semibold">OT Cleanroom Sterility</span>
              </div>
              <div className="bg-[#05070a]/60 p-4 rounded-lg border border-white/10">
                <span className="block text-xl font-serif text-white">HEPA H14</span>
                <span className="block text-[10px] text-white/40 mt-1 uppercase font-semibold">99.995% Pathogen Filtration</span>
              </div>
              <div className="bg-[#05070a]/60 p-4 rounded-lg border border-white/10">
                <span className="block text-xl font-serif text-teal-400">NABH V5</span>
                <span className="block text-[10px] text-white/40 mt-1 uppercase font-semibold">Certified Hospital Outlays</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
