/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Activity, Menu, X, ArrowRight } from 'lucide-react';

interface NavbarProps {
  activeSection: string;
  scrollToSection: (id: string) => void;
}

export default function Navbar({ activeSection, scrollToSection }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Services', id: 'services' },
    { label: 'HMS Simulator', id: 'hms-simulator' },
    { label: 'Infrastructure', id: 'infrastructure' },
    { label: 'About Us', id: 'about' },
    { label: 'Contact', id: 'contact' },
  ];

  const handleNavClick = (id: string) => {
    scrollToSection(id);
    setIsMobileMenuOpen(false);
  };

  return (
    <nav
      id="main-navigation"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#05070a]/95 backdrop-blur-md border-b border-white/10 shadow-lg py-4'
          : 'bg-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-8 flex items-center justify-between">
        {/* Brand Logo */}
        <div
          id="brand-logo"
          onClick={() => handleNavClick('hero')}
          className="flex items-center space-x-3 cursor-pointer group"
        >
          <div className="relative h-10 w-10 rounded-lg overflow-hidden border border-white/10 bg-white/5 flex items-center justify-center transition-all duration-200 group-hover:border-teal-400/30">
            <img 
              src="/src/assets/images/raphalink_logo_1787009618295.jpg" 
              alt="RaphaLink Logo" 
              className="h-full w-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <span className="font-serif font-normal text-lg md:text-xl text-white tracking-tight">
              Rapha<span className="text-teal-400">Link</span>
            </span>
            <span className="block text-[9px] text-white/40 uppercase tracking-widest leading-none font-semibold mt-0.5">
              Healthcare Pvt Ltd
            </span>
          </div>
        </div>

        {/* Desktop Nav Items */}
        <div id="desktop-menu" className="hidden lg:flex items-center space-x-8">
          {navItems.map((item) => (
            <button
              key={item.id}
              id={`nav-link-${item.id}`}
              onClick={() => handleNavClick(item.id)}
              className={`font-sans text-xs uppercase tracking-widest font-medium transition-colors duration-200 cursor-pointer ${
                activeSection === item.id
                  ? 'text-teal-400 font-bold'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Action Call to Action */}
        <div className="hidden lg:block">
          <button
            id="nav-cta-button"
            onClick={() => handleNavClick('contact')}
            className="font-sans inline-flex items-center space-x-2 bg-white text-black hover:bg-teal-400 hover:text-black px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all duration-200 shadow-md shadow-teal-400/5 cursor-pointer group"
          >
            <span>Inquire & Partner</span>
            <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Mobile Menu Trigger */}
        <div className="lg:hidden flex items-center">
          <button
            id="mobile-menu-toggle"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="text-white/80 hover:text-white p-1"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Overlay */}
      {isMobileMenuOpen && (
        <div
          id="mobile-menu-drawer"
          className="lg:hidden fixed top-[73px] left-0 right-0 bg-[#05070a]/98 border-b border-white/10 shadow-2xl py-6 px-6 flex flex-col space-y-4 animate-in fade-in slide-in-from-top-4 duration-200 backdrop-blur-md"
        >
          {navItems.map((item) => (
            <button
              key={item.id}
              id={`mobile-nav-link-${item.id}`}
              onClick={() => handleNavClick(item.id)}
              className={`font-sans text-left text-xs uppercase tracking-widest py-2 transition-colors ${
                activeSection === item.id
                  ? 'text-teal-400 font-bold'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
          <div className="pt-4 border-t border-white/10">
            <button
              id="mobile-nav-cta"
              onClick={() => handleNavClick('contact')}
              className="font-sans w-full flex items-center justify-center space-x-2 bg-white text-black py-3 rounded-lg text-xs font-bold uppercase tracking-widest hover:bg-teal-400 hover:text-black transition-colors"
            >
              <span>Inquire & Partner</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
