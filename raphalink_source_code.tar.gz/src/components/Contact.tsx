/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Mail, Phone, Clock, ArrowRight, CheckCircle2, Copy, Sparkles, Send } from 'lucide-react';
import { InquiryFormState } from '../types';

export default function Contact() {
  const [form, setForm] = useState<InquiryFormState>({
    fullName: '',
    email: '',
    phone: '',
    organization: '',
    facilityType: 'Hospital (50-200 beds)',
    serviceInterest: 'both',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);

  const handleCopy = (text: string, type: 'email' | 'phone') => {
    navigator.clipboard.writeText(text);
    if (type === 'email') {
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2000);
    } else {
      setCopiedPhone(true);
      setTimeout(() => setCopiedPhone(false), 2000);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.fullName || !form.email || !form.phone) {
      alert('Please fill out the required fields: Full Name, Email, and Phone Number.');
      return;
    }

    setIsSubmitting(true);
    // Simulate API database transmission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 1500);
  };

  const handleReset = () => {
    setForm({
      fullName: '',
      email: '',
      phone: '',
      organization: '',
      facilityType: 'Hospital (50-200 beds)',
      serviceInterest: 'both',
      message: ''
    });
    setIsSubmitted(false);
  };

  return (
    <section
      id="contact"
      className="bg-[#05070a] text-white py-24 px-6 md:px-8 border-t border-white/10 scroll-mt-20 relative"
    >
      <div className="absolute top-0 left-1/3 w-96 h-96 bg-teal-400/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto space-y-16">
        {/* Editorial Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <span className="text-teal-400 font-sans text-xs uppercase tracking-[0.2em] font-bold block">
            Partner With Us
          </span>
          <h2 className="font-serif text-3xl md:text-4xl font-normal text-white tracking-tight animate-fade-in">
            Inquiries & Partnership Opportunities
          </h2>
          <div className="h-0.5 w-12 bg-teal-400 mx-auto rounded" />
          <p className="font-sans text-sm md:text-base text-white/60">
            Discuss modular OT cleanroom specifications or arrange a detailed digital walkthrough of our HMS software suite with our executive team.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          {/* Direct Channels - Col 5 */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-8">
            <div className="space-y-6">
              <h3 className="font-serif text-2xl font-normal text-white">
                Let's Coordinate Your Systems
              </h3>
              <p className="font-sans text-white/60 text-sm leading-relaxed">
                Connect directly with the RaphaLink Healthcare partnership board. We are fully equipped to handle large-scale greenfield construction programs, modular medical pipeline overhauls, or clinic digitization sweeps.
              </p>

              {/* Contact Channels Cards */}
              <div className="space-y-4">
                {/* Email Card */}
                <div className="bg-white/5 border border-white/10 p-5 rounded-xl flex items-start space-x-4 hover:border-white/20 transition-all">
                  <div className="bg-teal-400/10 text-teal-400 p-3 rounded-lg flex-shrink-0">
                    <Mail className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="block text-[9px] text-white/40 font-bold uppercase tracking-widest">
                      Executive Partnership Email
                    </span>
                    <a
                      href="mailto:raphalinkglobal@gmail.com"
                      className="block font-sans text-sm md:text-base font-bold text-white hover:text-teal-400 transition-all truncate mt-1"
                    >
                      raphalinkglobal@gmail.com
                    </a>
                  </div>
                  <button
                    id="copy-email-btn"
                    onClick={() => handleCopy('raphalinkglobal@gmail.com', 'email')}
                    className="p-1 text-white/40 hover:text-white/80 self-center relative cursor-pointer"
                    aria-label="Copy Email"
                  >
                    <Copy className="h-4 w-4" />
                    {copiedEmail && (
                      <span className="absolute bottom-full right-0 bg-[#05070a] text-[10px] text-teal-400 px-2 py-0.5 rounded border border-white/10 shadow-xl mb-1 whitespace-nowrap">
                        Copied!
                      </span>
                    )}
                  </button>
                </div>

                {/* Phone Card */}
                <div className="bg-white/5 border border-white/10 p-5 rounded-xl flex items-start space-x-4 hover:border-white/20 transition-all">
                  <div className="bg-teal-400/10 text-teal-400 p-3 rounded-lg flex-shrink-0">
                    <Phone className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="block text-[9px] text-white/40 font-bold uppercase tracking-widest">
                      Direct Hotline & WhatsApp
                    </span>
                    <a
                      href="tel:+919995774304"
                      className="block font-sans text-sm md:text-base font-bold text-white hover:text-teal-400 transition-all mt-1"
                    >
                      +91 9995774304
                    </a>
                  </div>
                  <button
                    id="copy-phone-btn"
                    onClick={() => handleCopy('+91 9995774304', 'phone')}
                    className="p-1 text-white/40 hover:text-white/80 self-center relative cursor-pointer"
                    aria-label="Copy Phone"
                  >
                    <Copy className="h-4 w-4" />
                    {copiedPhone && (
                      <span className="absolute bottom-full right-0 bg-[#05070a] text-[10px] text-teal-400 px-2 py-0.5 rounded border border-white/10 shadow-xl mb-1 whitespace-nowrap">
                        Copied!
                      </span>
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Direct Support Notice */}
            <div className="bg-white/5 border border-white/10 p-5 rounded-xl flex items-start space-x-3.5">
              <Clock className="h-5 w-5 text-teal-400 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-serif text-sm text-white">Immediate Consultation Support</h4>
                <p className="font-sans text-[11px] text-white/50 mt-0.5 leading-relaxed">
                  We maintain responsive support loops for ongoing partnerships. Typical response duration for structural blueprints or software configuration quotes is under 12 hours.
                </p>
              </div>
            </div>
          </div>

          {/* Interactive Form - Col 7 */}
          <div className="lg:col-span-7">
            <div className="bg-white/5 border border-white/10 rounded-xl p-6 md:p-8 shadow-sm">
              {!isSubmitted ? (
                <form id="partnership-inquiry-form" onSubmit={handleSubmit} className="space-y-6">
                  <div className="flex items-center space-x-2 pb-2 border-b border-white/10">
                    <Sparkles className="h-4 w-4 text-teal-400" />
                    <h4 className="font-sans text-[10px] font-bold text-white/40 uppercase tracking-widest">
                      Electronic Partnership Briefing
                    </h4>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {/* Full Name */}
                    <div className="space-y-2">
                      <label htmlFor="fullName" className="font-sans text-xs font-bold text-white/50 block">
                        Full Name <span className="text-teal-400">*</span>
                      </label>
                      <input
                        id="fullName"
                        type="text"
                        required
                        placeholder="Dr. John Doe"
                        value={form.fullName}
                        onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                        disabled={isSubmitting}
                        className="font-sans w-full text-xs md:text-sm px-4 py-3 bg-[#05070a]/50 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400/20 focus:border-teal-400 transition-all text-white disabled:opacity-50"
                      />
                    </div>

                    {/* Email */}
                    <div className="space-y-2">
                      <label htmlFor="email" className="font-sans text-xs font-bold text-white/50 block">
                        Institutional Email <span className="text-teal-400">*</span>
                      </label>
                      <input
                        id="email"
                        type="email"
                        required
                        placeholder="john.doe@hospital.com"
                        value={form.email}
                        onChange={(e) => setForm({ ...form, email: e.target.value })}
                        disabled={isSubmitting}
                        className="font-sans w-full text-xs md:text-sm px-4 py-3 bg-[#05070a]/50 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400/20 focus:border-teal-400 transition-all text-white disabled:opacity-50"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {/* Phone */}
                    <div className="space-y-2">
                      <label htmlFor="phone" className="font-sans text-xs font-bold text-white/50 block">
                        Contact Phone <span className="text-teal-400">*</span>
                      </label>
                      <input
                        id="phone"
                        type="tel"
                        required
                        placeholder="+91 98765 43210"
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        disabled={isSubmitting}
                        className="font-sans w-full text-xs md:text-sm px-4 py-3 bg-[#05070a]/50 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400/20 focus:border-teal-400 transition-all text-white disabled:opacity-50"
                      />
                    </div>

                    {/* Organization Name */}
                    <div className="space-y-2">
                      <label htmlFor="organization" className="font-sans text-xs font-bold text-white/50 block">
                        Hospital / Organization Name
                      </label>
                      <input
                        id="organization"
                        type="text"
                        placeholder="Narayana Medicity"
                        value={form.organization}
                        onChange={(e) => setForm({ ...form, organization: e.target.value })}
                        disabled={isSubmitting}
                        className="font-sans w-full text-xs md:text-sm px-4 py-3 bg-[#05070a]/50 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400/20 focus:border-teal-400 transition-all text-white disabled:opacity-50"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {/* Facility Type */}
                    <div className="space-y-2">
                      <label htmlFor="facilityType" className="font-sans text-xs font-bold text-white/50 block">
                        Estimated Facility Size
                      </label>
                      <select
                        id="facilityType"
                        value={form.facilityType}
                        onChange={(e) => setForm({ ...form, facilityType: e.target.value })}
                        disabled={isSubmitting}
                        className="font-sans w-full text-xs md:text-sm px-4 py-3 bg-[#05070a] border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400/20 focus:border-teal-400 transition-all text-white disabled:opacity-50"
                      >
                        <option className="bg-[#05070a] text-white">Daycare Clinic & Lab</option>
                        <option className="bg-[#05070a] text-white">Hospital (50-200 beds)</option>
                        <option className="bg-[#05070a] text-white">Multi-specialty Core Center (200+ beds)</option>
                        <option className="bg-[#05070a] text-white">Upcoming Greenfield Build</option>
                      </select>
                    </div>

                    {/* Services of Interest */}
                    <div className="space-y-2">
                      <label htmlFor="serviceInterest" className="font-sans text-xs font-bold text-white/50 block">
                        Solutions Required
                      </label>
                      <select
                        id="serviceInterest"
                        value={form.serviceInterest}
                        onChange={(e) => setForm({ ...form, serviceInterest: e.target.value as any })}
                        disabled={isSubmitting}
                        className="font-sans w-full text-xs md:text-sm px-4 py-3 bg-[#05070a] border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400/20 focus:border-teal-400 transition-all text-white disabled:opacity-50"
                      >
                        <option value="both" className="bg-[#05070a] text-white">Both (Turnkey Build + HMS Suite)</option>
                        <option value="infrastructure" className="bg-[#05070a] text-white">Physical Infrastructure Construction</option>
                        <option value="hms" className="bg-[#05070a] text-white">HMS Custom Software Solution</option>
                        <option value="other" className="bg-[#05070a] text-white">General Partnership / Other</option>
                      </select>
                    </div>
                  </div>

                  {/* Message */}
                  <div className="space-y-2">
                    <label htmlFor="message" className="font-sans text-xs font-bold text-white/50 block">
                      Inquiry Narrative / Details
                    </label>
                    <textarea
                      id="message"
                      rows={3}
                      placeholder="Please share any project timeline objectives, pipeline standard demands, or existing software friction..."
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      disabled={isSubmitting}
                      className="font-sans w-full text-xs md:text-sm px-4 py-3 bg-[#05070a]/50 border border-white/10 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400/20 focus:border-teal-400 transition-all text-white disabled:opacity-50 resize-none"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    id="submit-inquiry-btn"
                    type="submit"
                    disabled={isSubmitting}
                    className="font-sans w-full flex items-center justify-center space-x-2 bg-white hover:bg-teal-400 text-black font-bold py-4 rounded-none text-xs md:text-sm uppercase tracking-wider transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-2 border-slate-950 border-t-transparent" />
                        <span>Transmitting briefing packet...</span>
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4" />
                        <span>Transmit Secure Partnership Briefing</span>
                      </>
                    )}
                  </button>
                </form>
              ) : (
                <div id="form-success-card" className="text-center py-8 space-y-6 animate-in zoom-in-95 duration-200">
                  <div className="bg-teal-400/10 text-teal-400 p-4 rounded-full inline-block">
                    <CheckCircle2 className="h-12 w-12" />
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-serif text-xl text-white">Briefing Transmitted Successfully</h4>
                    <p className="font-sans text-sm text-white/60 max-w-md mx-auto leading-relaxed">
                      Thank you, <span className="font-semibold text-white">{form.fullName}</span>! Your coordination request has been submitted directly to the RaphaLink Healthcare executive board.
                    </p>
                  </div>

                  <div className="bg-white/5 border border-white/10 rounded-lg p-5 max-w-md mx-auto text-left text-xs md:text-sm space-y-2 text-white/60">
                    <p><strong className="text-white">Organization:</strong> {form.organization || 'Independent/Private'}</p>
                    <p><strong className="text-white">Facility Size:</strong> {form.facilityType}</p>
                    <p><strong className="text-white">Routing Channel:</strong> {form.serviceInterest === 'both' ? 'Hybrid Infrastructure + Software Queue' : form.serviceInterest === 'infrastructure' ? 'Structural Construction Division' : 'Digital HMS Division'}</p>
                    <p><strong className="text-white">Contact Point:</strong> We will reach out to you via <span className="font-mono text-teal-400">{form.email}</span> or <span className="font-mono text-teal-400">{form.phone}</span> within 12 business hours.</p>
                  </div>

                  <button
                    id="reset-form-btn"
                    onClick={handleReset}
                    className="font-sans text-xs font-bold text-teal-400 hover:text-teal-300 cursor-pointer underline"
                  >
                    Send another inquiry
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
