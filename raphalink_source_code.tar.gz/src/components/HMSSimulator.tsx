/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Calculator,
  Activity,
  Bed,
  Sparkles,
  RefreshCw,
  Plus,
  Play,
  CheckCircle2,
  Clock,
  ShieldAlert,
  Gauge,
  ClipboardList
} from 'lucide-react';
import { HOSPITAL_SIZES, PAIN_POINTS, INITIAL_EVENTS } from '../data';
import { HospitalSizeOption, PainPointOption, SimulatedEvent } from '../types';

export default function HMSSimulator() {
  // Configurator state
  const [selectedSize, setSelectedSize] = useState<HospitalSizeOption>(HOSPITAL_SIZES[1]); // Midsize default
  const [selectedPains, setSelectedPains] = useState<string[]>(['slow-discharge', 'bed-coordination']);

  // Dynamic simulation simulation states
  const [workflowIndex, setWorkflowIndex] = useState(58);
  const [hoursSaved, setHoursSaved] = useState(1400);
  const [dischargeMinutes, setDischargeMinutes] = useState(110);

  // Wards interactive sandbox state
  const [beds, setBeds] = useState([
    { id: 1, ward: 'ICU-A', num: 'Bed 01', status: 'occupied', patient: 'A. Sharma' },
    { id: 2, ward: 'ICU-A', num: 'Bed 02', status: 'occupied', patient: 'S. Patel' },
    { id: 3, ward: 'ICU-A', num: 'Bed 03', status: 'cleaning', patient: 'None' },
    { id: 4, ward: 'ICU-A', num: 'Bed 04', status: 'empty', patient: 'None' },
    { id: 5, ward: 'General-B', num: 'Bed 01', status: 'occupied', patient: 'K. Nair' },
    { id: 6, ward: 'General-B', num: 'Bed 02', status: 'empty', patient: 'None' },
    { id: 7, ward: 'General-B', num: 'Bed 03', status: 'occupied', patient: 'M. Khan' },
    { id: 8, ward: 'General-B', num: 'Bed 04', status: 'empty', patient: 'None' },
    { id: 9, ward: 'General-B', num: 'Bed 05', status: 'empty', patient: 'None' },
    { id: 10, ward: 'General-B', num: 'Bed 06', status: 'cleaning', patient: 'None' },
    { id: 11, ward: 'Paediatric', num: 'Bed 01', status: 'occupied', patient: 'Baby of Mary' },
    { id: 12, ward: 'Paediatric', num: 'Bed 02', status: 'empty', patient: 'None' },
  ]);

  // Live simulated system events
  const [events, setEvents] = useState<SimulatedEvent[]>(INITIAL_EVENTS);
  const eventIdCounter = useRef(6);

  // Re-calculate ROI metrics whenever selected configuration changes
  useEffect(() => {
    // Math logic based on selection
    const baseIndex = selectedSize.id === 'clinic' ? 62 : selectedSize.id === 'midsize' ? 48 : 36;
    const resolvedPainsCount = selectedPains.length;

    // Calculate sum of pain point improvements
    const totalEfficiencyGain = PAIN_POINTS
      .filter(p => selectedPains.includes(p.id))
      .reduce((acc, curr) => acc + curr.efficiencyGain, 0);

    const calculatedIndex = Math.min(98, baseIndex + totalEfficiencyGain);

    // Reclaimed hours calculation
    const baseMultiplier = selectedSize.avgDailyPatients * selectedSize.multiplier;
    const calculatedHours = Math.round(baseMultiplier * (resolvedPainsCount * 180));

    // Discharge time calculation (recedes as you resolve discharge issues)
    let dischargeTime = 180; // minutes base
    if (selectedPains.includes('slow-discharge')) {
      dischargeTime -= 115;
    }
    if (selectedPains.includes('bed-coordination')) {
      dischargeTime -= 30;
    }

    setWorkflowIndex(calculatedIndex);
    setHoursSaved(calculatedHours);
    setDischargeMinutes(Math.max(15, dischargeTime));
  }, [selectedSize, selectedPains]);

  const togglePainPoint = (painId: string) => {
    if (selectedPains.includes(painId)) {
      setSelectedPains(selectedPains.filter(id => id !== painId));
    } else {
      setSelectedPains([...selectedPains, painId]);
    }
  };

  const handleBedClick = (bedId: number) => {
    setBeds(prevBeds =>
      prevBeds.map(bed => {
        if (bed.id === bedId) {
          let newStatus: 'empty' | 'occupied' | 'cleaning' = 'empty';
          let newPatient = 'None';

          if (bed.status === 'empty') {
            newStatus = 'occupied';
            newPatient = ['R. Verma', 'J. Joseph', 'A. Menon', 'S. Rao'][Math.floor(Math.random() * 4)];
          } else if (bed.status === 'occupied') {
            newStatus = 'cleaning';
          } else {
            newStatus = 'empty';
          }

          // Trigger log to simulator
          const stamp = new Date().toTimeString().split(' ')[0];
          const actionWord = newStatus === 'occupied' ? `allocated to Patient ${newPatient}` : newStatus === 'cleaning' ? 'flagged for sanitation protocols' : 'released and marked vacant';
          const newEvent: SimulatedEvent = {
            id: `evt-custom-${eventIdCounter.current++}`,
            timestamp: stamp,
            message: `Manual Grid Sync: ${bed.ward} ${bed.num} has been ${actionWord}.`,
            type: newStatus === 'occupied' ? 'success' : newStatus === 'cleaning' ? 'warning' : 'info',
            category: 'operational'
          };

          setEvents(prev => [newEvent, ...prev.slice(0, 5)]);

          return { ...bed, status: newStatus, patient: newPatient };
        }
        return bed;
      })
    );
  };

  const simulateEmergencyAdmission = () => {
    // Find first empty bed
    const emptyBedIndex = beds.findIndex(b => b.status === 'empty');
    if (emptyBedIndex === -1) {
      // Force release bed 4 for emergency
      setBeds(prev => prev.map(b => b.id === 4 ? { ...b, status: 'empty', patient: 'None' } : b));
      return;
    }

    const targetBed = beds[emptyBedIndex];
    const patientName = ['P. Pillai', 'T. Thomas', 'L. George', 'N. Das'][Math.floor(Math.random() * 4)];

    setBeds(prev =>
      prev.map(b => (b.id === targetBed.id ? { ...b, status: 'occupied', patient: patientName } : b))
    );

    const stamp = new Date().toTimeString().split(' ')[0];
    const alarmEvent: SimulatedEvent = {
      id: `evt-custom-${eventIdCounter.current++}`,
      timestamp: stamp,
      message: `PRIORITY 1 EMERGENCY: Triage synchronized. ${targetBed.ward} ${targetBed.num} allocated to ${patientName}. Medical Gas pressure boosted.`,
      type: 'alert',
      category: 'clinical'
    };

    setEvents(prev => [alarmEvent, ...prev.slice(0, 5)]);
  };

  return (
    <section
      id="hms-simulator"
      className="bg-[#05070a] text-white py-24 px-6 md:px-8 relative scroll-mt-20 overflow-hidden border-t border-white/10"
    >
      {/* Background patterns */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,rgba(20,184,166,0.05),transparent_50%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto space-y-16 relative z-10">
        {/* Header Block */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <span className="text-teal-400 font-sans text-xs uppercase tracking-[0.2em] font-bold block">
            Interactive System Sandbox
          </span>
          <h2 className="font-serif text-3xl md:text-4xl font-normal text-white tracking-tight">
            Simulate Your Facility Coordination Gains
          </h2>
          <div className="h-0.5 w-12 bg-teal-400 mx-auto rounded" />
          <p className="font-sans text-sm md:text-base text-white/60">
            Configure your medical facility scale and toggle current administrative problems. Watch our Hospital Management System mathematically resolve issues and coordinate the clinical grid.
          </p>
        </div>

        {/* Major Grid layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          {/* Configurator Card - Col 7 */}
          <div className="lg:col-span-7 bg-white/5 border border-white/10 rounded-xl p-6 md:p-8 flex flex-col justify-between space-y-8">
            <div className="space-y-6">
              {/* Header */}
              <div className="flex items-center space-x-3 pb-4 border-b border-white/10">
                <Calculator className="h-5 w-5 text-teal-400" />
                <h3 className="font-serif text-lg text-white">Facility Operational Optimizer</h3>
              </div>

              {/* Step 1: Hospital Size */}
              <div className="space-y-3">
                <label className="font-sans text-[10px] font-bold text-white/50 uppercase tracking-widest block">
                  Step 1: Select Facility Scale
                </label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {HOSPITAL_SIZES.map((size) => (
                    <button
                      key={size.id}
                      id={`size-btn-${size.id}`}
                      onClick={() => setSelectedSize(size)}
                      className={`p-4 rounded-lg text-left border transition-all cursor-pointer flex flex-col justify-between ${
                        selectedSize.id === size.id
                          ? 'bg-teal-400/10 border-teal-400 text-teal-400 shadow-sm'
                          : 'bg-[#05070a]/50 border-white/10 text-white/70 hover:border-white/20'
                      }`}
                    >
                      <div>
                        <span className="block font-sans text-sm font-bold leading-tight">{size.name}</span>
                        <span className="block font-sans text-[11px] text-white/40 mt-1">{size.description}</span>
                      </div>
                      <span className="block font-sans text-xs text-teal-400 font-bold mt-4">
                        {size.bedsRange}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 2: Pain points */}
              <div className="space-y-3 pt-2">
                <label className="font-sans text-[10px] font-bold text-white/50 uppercase tracking-widest block">
                  Step 2: Check Wastes to Address with HMS & Infrastructure Design
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {PAIN_POINTS.map((pain) => {
                    const isSelected = selectedPains.includes(pain.id);
                    return (
                      <button
                        key={pain.id}
                        id={`pain-btn-${pain.id}`}
                        onClick={() => togglePainPoint(pain.id)}
                        className={`p-4 rounded-lg text-left border transition-all cursor-pointer flex items-start space-x-3 ${
                          isSelected
                            ? 'bg-teal-400/5 border-teal-400/60 text-white shadow-sm'
                            : 'bg-[#05070a]/40 border-white/10 text-white/60 hover:border-white/20'
                        }`}
                      >
                        <div className={`mt-0.5 rounded border h-4.5 w-4.5 flex items-center justify-center flex-shrink-0 transition-all ${
                          isSelected
                            ? 'bg-teal-400 border-teal-400 text-black'
                            : 'border-white/20'
                        }`}>
                          {isSelected && <CheckCircle2 className="h-3 w-3 stroke-[3]" />}
                        </div>
                        <div>
                          <span className={`block font-sans text-xs md:text-sm font-bold ${isSelected ? 'text-white' : 'text-white/80'}`}>
                            {pain.label}
                          </span>
                          <span className="block font-sans text-[11px] text-white/50 mt-1 leading-snug">
                            {pain.description}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Simulated Return Widget */}
            <div className="bg-[#05070a]/60 border border-white/10 p-5 rounded-lg grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
              <div>
                <span className="block text-[9px] text-white/40 font-bold uppercase tracking-widest">
                  Workflow Index
                </span>
                <div className="flex items-center justify-center space-x-1.5 mt-2">
                  <span className="text-3xl font-serif text-teal-400">{workflowIndex}%</span>
                </div>
                <span className="text-[10px] text-white/40 block mt-1">Excellent Operational Flow</span>
              </div>

              <div className="border-t md:border-t-0 md:border-x border-white/10 py-4 md:py-0">
                <span className="block text-[9px] text-white/40 font-bold uppercase tracking-widest">
                  Staff Hours Saved / Yr
                </span>
                <span className="block text-3xl font-serif text-white mt-2">
                  {hoursSaved.toLocaleString()} hr
                </span>
                <span className="text-[10px] text-white/40 block mt-1">Reclaimed for patient care</span>
              </div>

              <div>
                <span className="block text-[9px] text-white/40 font-bold uppercase tracking-widest">
                  Discharge Invoicing
                </span>
                <span className="block text-3xl font-serif text-white mt-2">
                  {dischargeMinutes} mins
                </span>
                <span className="text-[10px] text-white/40 block mt-1">From multiple hours baseline</span>
              </div>
            </div>
          </div>

          {/* Interactive Live Monitor Sandbox - Col 5 */}
          <div className="lg:col-span-5 bg-white/5 border border-white/10 rounded-xl p-6 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-white/10">
                <div className="flex items-center space-x-3">
                  <Activity className="h-5 w-5 text-teal-400 animate-pulse" />
                  <h3 className="font-serif text-lg text-white">Live Coordination Grid</h3>
                </div>
                <span className="bg-teal-400/10 text-teal-400 text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border border-teal-500/20">
                  Online
                </span>
              </div>

              {/* Subtitle instructions */}
              <p className="font-sans text-xs text-white/60">
                Interact with the clinical ward mapping below. Tap any bed to toggle states (Occupied → Needs Cleaning → Vacant) and update the central ledger.
              </p>

              {/* Interactive Grid Map */}
              <div className="grid grid-cols-4 gap-3 bg-[#05070a]/60 p-4 rounded-lg border border-white/10">
                {beds.map((bedItem) => (
                  <button
                    key={bedItem.id}
                    id={`bed-slot-${bedItem.id}`}
                    onClick={() => handleBedClick(bedItem.id)}
                    className={`p-2.5 rounded-lg text-center transition-all cursor-pointer relative group border ${
                      bedItem.status === 'occupied'
                        ? 'bg-blue-900/40 border-blue-500/40 text-blue-200'
                        : bedItem.status === 'cleaning'
                        ? 'bg-amber-900/40 border-amber-500/40 text-amber-200'
                        : 'bg-teal-950/20 border-teal-500/30 text-teal-400 hover:border-teal-400'
                    }`}
                  >
                    <Bed className="h-4 w-4 mx-auto mb-1.5" />
                    <span className="block text-[9px] font-bold uppercase tracking-wider truncate leading-none">
                      {bedItem.ward}
                    </span>
                    <span className="block text-[8px] text-white/40 mt-1 leading-none">
                      {bedItem.num}
                    </span>

                    {/* Tooltip on hover */}
                    <span className="hidden group-hover:block absolute bottom-full left-1/2 transform -translate-x-1/2 bg-slate-950 text-[10px] text-white px-2 py-1 rounded shadow-xl border border-slate-800 z-20 whitespace-nowrap mb-1">
                      {bedItem.status === 'occupied' ? `Patient: ${bedItem.patient}` : bedItem.status === 'cleaning' ? 'Sanitizing...' : 'Vacant (Click to Admit)'}
                    </span>
                  </button>
                ))}
              </div>

              {/* Interactive buttons */}
              <div className="flex items-center space-x-3 pt-2">
                <button
                  id="btn-emergency-simulate"
                  onClick={simulateEmergencyAdmission}
                  className="font-sans flex-1 inline-flex items-center justify-center space-x-2 bg-white hover:bg-teal-400 text-black text-xs font-bold uppercase tracking-wider py-3 px-4 rounded-none transition-all cursor-pointer"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Simulate Urgent Admission</span>
                </button>
              </div>
            </div>

            {/* Live Orchestration Ledger (Ticker) */}
            <div className="space-y-3">
              <span className="font-sans text-[10px] font-bold text-white/40 uppercase tracking-widest block">
                Central Event Dispatcher Logs
              </span>
              <div className="bg-[#05070a] border border-white/10 rounded-lg p-3.5 h-[135px] overflow-y-auto font-mono text-[10px] space-y-2 divide-y divide-white/5">
                {events.map((evt) => (
                  <div key={evt.id} className="flex items-start space-x-2 pt-1.5 first:pt-0 pb-1.5 last:pb-0">
                    <span className="text-white/40 flex-shrink-0">[{evt.timestamp}]</span>
                    <span className={`flex-shrink-0 uppercase text-[8px] font-bold px-1 py-0.2 rounded ${
                      evt.type === 'alert'
                        ? 'bg-rose-500/10 text-rose-400'
                        : evt.type === 'warning'
                        ? 'bg-amber-500/10 text-amber-400'
                        : evt.type === 'success'
                        ? 'bg-teal-500/10 text-teal-400'
                        : 'bg-indigo-500/10 text-indigo-400'
                    }`}>
                      {evt.category}
                    </span>
                    <span className="text-white/80 leading-snug">{evt.message}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
