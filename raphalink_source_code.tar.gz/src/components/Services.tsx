/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Building2,
  Layers,
  Gauge,
  Wind,
  ClipboardList,
  Bed,
  CalendarRange,
  PackageCheck,
  Receipt,
  CheckCircle2,
  ChevronRight,
  Info,
  X
} from 'lucide-react';
import { INFRASTRUCTURE_SERVICES, HMS_FEATURES } from '../data';
import { InfrastructureService, HMSFeature } from '../types';

// Helper to map icon name to Lucide components
const IconMap = ({ name, className }: { name: string; className: string }) => {
  switch (name) {
    case 'Building2': return <Building2 className={className} />;
    case 'Layers': return <Layers className={className} />;
    case 'Gauge': return <Gauge className={className} />;
    case 'Wind': return <Wind className={className} />;
    case 'ClipboardList': return <ClipboardList className={className} />;
    case 'Bed': return <Bed className={className} />;
    case 'CalendarRange': return <CalendarRange className={className} />;
    case 'PackageCheck': return <PackageCheck className={className} />;
    case 'Receipt': return <Receipt className={className} />;
    default: return <Building2 className={className} />;
  }
};

export default function Services() {
  const [activeTab, setActiveTab] = useState<'infrastructure' | 'hms'>('infrastructure');
  const [selectedInfra, setSelectedInfra] = useState<InfrastructureService | null>(null);
  const [selectedHMS, setSelectedHMS] = useState<HMSFeature | null>(null);

  return (
    <section
      id="services"
      className="bg-[#05070a] text-white py-24 px-6 md:px-8 border-t border-white/10 relative scroll-mt-20"
    >
      <div className="max-w-7xl mx-auto space-y-16">
        {/* Editorial Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <span className="text-teal-400 font-sans text-xs uppercase tracking-[0.2em] font-bold block">
            What We Deliver
          </span>
          <h2 className="font-serif text-3xl md:text-4xl font-normal text-white tracking-tight">
            Integrated Services for Seamless Coordination
          </h2>
          <div className="h-0.5 w-12 bg-teal-400 mx-auto rounded" />
          <p className="font-sans text-sm md:text-base text-white/60">
            We solve the integration gap between a hospital’s physical layout and its digital management. Explore our physical engineering capabilities or our Hospital Management System features.
          </p>
        </div>

        {/* Dynamic Nav Switches */}
        <div className="flex justify-center max-w-lg mx-auto bg-white/5 p-1.5 rounded-xl border border-white/10">
          <button
            id="tab-infra"
            onClick={() => {
              setActiveTab('infrastructure');
              setSelectedInfra(null);
              setSelectedHMS(null);
            }}
            className={`flex-1 py-3 px-4 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center space-x-2 ${
              activeTab === 'infrastructure'
                ? 'bg-teal-400 text-slate-950 shadow-lg'
                : 'text-white/60 hover:text-white'
            }`}
          >
            <Building2 className="h-4 w-4" />
            <span>Infrastructure</span>
          </button>
          <button
            id="tab-hms"
            onClick={() => {
              setActiveTab('hms');
              setSelectedInfra(null);
              setSelectedHMS(null);
            }}
            className={`flex-1 py-3 px-4 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center space-x-2 ${
              activeTab === 'hms'
                ? 'bg-teal-400 text-slate-950 shadow-lg'
                : 'text-white/60 hover:text-white'
            }`}
          >
            <ClipboardList className="h-4 w-4" />
            <span>HMS Software</span>
          </button>
        </div>

        {/* Content Panel: Infrastructure */}
        {activeTab === 'infrastructure' && (
          <div id="infra-services-grid" className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-in fade-in duration-300">
            {INFRASTRUCTURE_SERVICES.map((item) => (
              <div
                key={item.id}
                id={`infra-card-${item.id}`}
                className="bg-white/5 border border-white/10 rounded-xl p-6 md:p-8 hover:border-teal-400/50 hover:shadow-2xl hover:shadow-teal-400/5 transition-all duration-300 flex flex-col justify-between group"
              >
                <div className="space-y-4">
                  {/* Icon Badge */}
                  <div className="bg-teal-400/10 text-teal-400 p-3.5 rounded-lg inline-block">
                    <IconMap name={item.iconName} className="h-6 w-6" />
                  </div>
                  {/* Title */}
                  <h3 className="font-serif text-xl font-normal text-white group-hover:text-teal-300 transition-colors">
                    {item.title}
                  </h3>
                  {/* Description */}
                  <p className="font-sans text-sm text-white/60 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                {/* Micro-bullet highlights */}
                <div className="mt-6 pt-6 border-t border-white/5 flex items-center justify-between">
                  <span className="text-[10px] font-bold text-teal-400 bg-teal-400/10 border border-teal-500/20 px-2.5 py-1 rounded-full">
                    NABH Guidelines
                  </span>
                  <button
                    id={`btn-infra-detail-${item.id}`}
                    onClick={() => setSelectedInfra(item)}
                    className="font-sans text-xs font-bold uppercase tracking-wider text-white/80 hover:text-teal-400 inline-flex items-center space-x-1 cursor-pointer transition-colors"
                  >
                    <span>Specifications</span>
                    <ChevronRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Content Panel: HMS Software */}
        {activeTab === 'hms' && (
          <div id="hms-services-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 animate-in fade-in duration-300">
            {HMS_FEATURES.map((item) => (
              <div
                key={item.id}
                id={`hms-card-${item.id}`}
                className="bg-white/5 border border-white/10 rounded-xl p-6 hover:border-teal-400/50 hover:shadow-2xl hover:shadow-teal-400/5 transition-all duration-300 flex flex-col justify-between group"
              >
                <div className="space-y-4">
                  {/* Dynamic Workflow Tag */}
                  <span className="block text-[10px] text-teal-400 font-extrabold uppercase tracking-wider">
                    {item.workflowStep}
                  </span>
                  {/* Icon & Heading */}
                  <div className="flex items-center space-x-3.5">
                    <div className="bg-teal-400/10 text-teal-400 p-2.5 rounded-lg flex-shrink-0">
                      <IconMap name={item.iconName} className="h-5 w-5" />
                    </div>
                    <h3 className="font-serif text-base text-white group-hover:text-teal-300 transition-colors line-clamp-1">
                      {item.title}
                    </h3>
                  </div>
                  {/* Description */}
                  <p className="font-sans text-xs md:text-sm text-white/60 leading-relaxed min-h-[4rem]">
                    {item.description}
                  </p>
                </div>

                {/* Impact Indicator Block */}
                <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between">
                  <div>
                    <span className="block text-[9px] uppercase tracking-widest text-white/40 font-semibold">
                      {item.impactMetrics.label}
                    </span>
                    <span className="text-sm font-extrabold text-teal-400">
                      {item.impactMetrics.value}
                    </span>
                  </div>
                  <button
                    id={`btn-hms-detail-${item.id}`}
                    onClick={() => setSelectedHMS(item)}
                    className="font-sans text-xs font-bold uppercase tracking-wider text-white/80 hover:text-teal-400 inline-flex items-center space-x-1 cursor-pointer transition-colors"
                  >
                    <span>Details</span>
                    <ChevronRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Detailed Modal Panel: Infrastructure */}
        {selectedInfra && (
          <div
            id="infra-modal-overlay"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-6"
            onClick={() => setSelectedInfra(null)}
          >
            <div
              id="infra-modal"
              className="bg-[#05070a] rounded-xl max-w-xl w-full p-6 md:p-8 shadow-2xl relative border border-white/10 space-y-6 animate-in zoom-in duration-150 text-white"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                id="close-infra-modal"
                onClick={() => setSelectedInfra(null)}
                className="absolute top-4 right-4 text-white/40 hover:text-white p-1"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="flex items-center space-x-4">
                <div className="bg-teal-400/10 text-teal-400 p-3 rounded-lg">
                  <IconMap name={selectedInfra.iconName} className="h-6 w-6" />
                </div>
                <h3 className="font-serif text-2xl font-normal text-white">
                  {selectedInfra.title}
                </h3>
              </div>

              <div className="space-y-2">
                <h4 className="font-sans text-xs font-bold text-teal-400 uppercase tracking-widest">
                  Description & Blueprint Strategy
                </h4>
                <p className="font-sans text-sm text-white/70 leading-relaxed">
                  {selectedInfra.detailedDescription}
                </p>
              </div>

              <div className="space-y-3 pt-2">
                <h4 className="font-sans text-xs font-bold text-teal-400 uppercase tracking-widest">
                  Technical Specifications Included
                </h4>
                <div className="grid grid-cols-1 gap-2.5">
                  {selectedInfra.highlights.map((highlight, index) => (
                    <div key={index} className="flex items-start space-x-3 bg-white/5 p-3 rounded-lg border border-white/5">
                      <CheckCircle2 className="h-4 w-4 text-teal-400 mt-0.5 flex-shrink-0" />
                      <span className="font-sans text-xs md:text-sm text-white/80">
                        {highlight}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Detailed Modal Panel: HMS Feature */}
        {selectedHMS && (
          <div
            id="hms-modal-overlay"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-6"
            onClick={() => setSelectedHMS(null)}
          >
            <div
              id="hms-modal"
              className="bg-[#05070a] rounded-xl max-w-xl w-full p-6 md:p-8 shadow-2xl relative border border-white/10 space-y-6 animate-in zoom-in duration-150 text-white"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                id="close-hms-modal"
                onClick={() => setSelectedHMS(null)}
                className="absolute top-4 right-4 text-white/40 hover:text-white p-1"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="space-y-2">
                <span className="bg-teal-400/10 text-teal-400 text-[10px] uppercase font-bold tracking-widest px-2.5 py-1 rounded border border-teal-500/20">
                  System Module: {selectedHMS.workflowStep}
                </span>
                <div className="flex items-center space-x-4 pt-2">
                  <div className="bg-teal-400/10 text-teal-400 p-3 rounded-lg">
                    <IconMap name={selectedHMS.iconName} className="h-6 w-6" />
                  </div>
                  <h3 className="font-serif text-2xl font-normal text-white">
                    {selectedHMS.title}
                  </h3>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-sans text-xs font-bold text-teal-400 uppercase tracking-widest">
                  Operational Description
                </h4>
                <p className="font-sans text-sm text-white/70 leading-relaxed">
                  {selectedHMS.detailedDescription}
                </p>
              </div>

              <div className="bg-teal-500/10 border border-teal-500/20 p-5 rounded-lg flex items-center justify-between">
                <div>
                  <span className="block text-xs text-white/50 uppercase tracking-widest font-semibold">
                    Expected Workflow Impact Metric
                  </span>
                  <span className="block text-xs text-teal-400 mt-0.5">
                    {selectedHMS.impactMetrics.label}
                  </span>
                </div>
                <div className="bg-teal-400 text-slate-950 px-4 py-2 rounded-lg font-extrabold text-lg shadow-sm">
                  {selectedHMS.impactMetrics.value}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
